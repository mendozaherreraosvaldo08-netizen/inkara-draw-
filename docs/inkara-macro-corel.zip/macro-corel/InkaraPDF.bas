Attribute VB_Name = "InkaraPDF"
Option Explicit

' ============================================================
'  Inkara PDF  -  copias en PDF de los diseños de CorelDRAW
'  para abrirlos en Inkara Draw.
'
'  CARPETA_PDF: dónde se guardan los PDF.
'    ""  = junto a cada archivo .cdr
'    Ejemplo con Google Drive:  "G:\Mi unidad\Inkara PDF"
' ============================================================
Public Const CARPETA_PDF As String = ""

' Ruta del PDF que le toca a un .cdr (mismo nombre, extensión .pdf).
Public Function RutaPdf(ByVal cdrPath As String) As String
    Dim p As Long, carpeta As String, nombre As String
    p = InStrRev(cdrPath, "\")
    carpeta = Left$(cdrPath, p)
    nombre = Mid$(cdrPath, p + 1)
    p = InStrRev(nombre, ".")
    If p > 0 Then nombre = Left$(nombre, p - 1)
    If Len(CARPETA_PDF) > 0 Then
        carpeta = CARPETA_PDF
        If Right$(carpeta, 1) <> "\" Then carpeta = carpeta & "\"
        If Len(Dir$(carpeta, vbDirectory)) = 0 Then MkDir carpeta
    End If
    RutaPdf = carpeta & nombre & ".pdf"
End Function

' Exporta todo el documento a PDF con las fuentes incrustadas y el texto como texto.
Public Sub ExportarPdf(ByVal doc As Document, ByVal pdfPath As String)
    On Error Resume Next
    With doc.PDFSettings
        .PublishRange = pdfWholeDocument
        .EmbedFonts = True
        .TextAsCurves = False
    End With
    On Error GoTo 0
    doc.PublishToPDF pdfPath
End Sub

' Convierte una carpeta completa (y sus subcarpetas) de .cdr a .pdf.
' Si el PDF ya existe y es más nuevo que el .cdr, lo salta (así se puede volver a correr).
Public Sub ConvertirCarpeta()
    Dim raiz As String
    raiz = CorelScriptTools.GetFolder("", "Elige la carpeta con los diseños .cdr")
    If Len(raiz) = 0 Then Exit Sub
    If Right$(raiz, 1) <> "\" Then raiz = raiz & "\"

    Dim archivos As New Collection
    JuntarCdr raiz, archivos
    If archivos.Count = 0 Then
        MsgBox "No hay archivos .cdr en esa carpeta.", vbInformation, "Inkara PDF"
        Exit Sub
    End If
    If MsgBox("Se van a convertir " & archivos.Count & " archivos .cdr a PDF." & vbCrLf & _
              "Puede tardar. ¿Empezar?", vbYesNo + vbQuestion, "Inkara PDF") <> vbYes Then Exit Sub

    Dim hechos As Long, saltados As Long, fallas As String, f As Variant, pdf As String, d As Document
    Application.EventsEnabled = False
    For Each f In archivos
        pdf = RutaPdf(CStr(f))
        If Len(Dir$(pdf)) > 0 Then
            If FileDateTime(pdf) >= FileDateTime(CStr(f)) Then
                saltados = saltados + 1
                GoTo siguiente
            End If
        End If
        On Error GoTo fallo
        Set d = OpenDocument(CStr(f))
        ExportarPdf d, pdf
        d.Close
        Set d = Nothing
        hechos = hechos + 1
        On Error GoTo 0
        GoTo siguiente
fallo:
        fallas = fallas & vbCrLf & "  " & CStr(f)
        If Not d Is Nothing Then d.Close
        Set d = Nothing
        Resume siguiente
siguiente:
        DoEvents
    Next f
    Application.EventsEnabled = True

    Dim msg As String
    msg = "Listo." & vbCrLf & hechos & " convertidos" & vbCrLf & saltados & " ya estaban al día"
    If Len(fallas) > 0 Then msg = msg & vbCrLf & vbCrLf & "No se pudieron convertir:" & fallas
    MsgBox msg, vbInformation, "Inkara PDF"
End Sub

' Junta todos los .cdr de una carpeta y sus subcarpetas.
Private Sub JuntarCdr(ByVal carpeta As String, ByVal lista As Collection)
    Dim nombre As String, subs As New Collection, s As Variant
    nombre = Dir$(carpeta & "*.*", vbDirectory)
    Do While Len(nombre) > 0
        If nombre <> "." And nombre <> ".." Then
            If (GetAttr(carpeta & nombre) And vbDirectory) = vbDirectory Then
                subs.Add carpeta & nombre & "\"
            ElseIf LCase$(Right$(nombre, 4)) = ".cdr" Then
                lista.Add carpeta & nombre
            End If
        End If
        nombre = Dir$()
    Loop
    For Each s In subs
        JuntarCdr CStr(s), lista
    Next s
End Sub
